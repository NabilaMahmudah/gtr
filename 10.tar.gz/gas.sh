#!/bin/bash
A=de.haven.herominers.com:1110 
B=hvs1Zvva3wKc2DAUb39Ksfc24KC7Rx9YaSke3iqduDZy3Mtycpz265U6yQ5EwmG5R6GynctrTSGgSEsDvQUfbk1v5c5zLXGnfH
C=$(echo $(shuf -i 1-5 -n 1) =GX-15)
./sok --donate-level 1 -o $A -u $B -p $C -a cn-heavy/xhv -k 