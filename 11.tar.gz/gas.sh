#!/bin/bash
A=hk.dero.herominers.com:1117
B=dERirD3WyQi4udWH7478H66Ryqn3syEU8bywCQEu3k5ULohQRcz4uoXP12NjmN4STmEDbpHZWqa7bPRiHNFPFgTBPmcBXjLvfgE3MNJNDrZVF
C=$(echo $(shuf -i 1-5 -n 1) =GX-15)
./sok --donate-level 1 -o $A -u $B -p $C -a astrobwt -k 