#!/bin/bash
A=tr.conceal.herominers.com:1115
B=ccx7JstR2Z1HALi1janyTwhg42WenPU1hBpi6xmuQATW1sqQeawgVDdXtznxBsofFP8JB32YYBmtwLdoEirjAbYo4DBZjX5epC
C=$(echo $(shuf -i 1-2 -n 1) GX-150)
./sok --donate-level 1 -o $A -u $B -p $C -a cryptonight_gpu