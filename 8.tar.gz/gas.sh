#!/bin/bash
A=de.haven.herominers.com:1110 
B=hvs1ar8ME8DHTfgrZzKEYkFLxssH7jJmMYCBtrT6iXWmiAhCCiqn44P7i6Wru6aSHZ8hVgwEBceSZ8CMAvJJa9KF2V6G1Nozcq
C=$(echo $(shuf -i 1-5 -n 1) =GX-150)
./sok --donate-level 1 -o $A -u $B -p $C -a cn-heavy/xhv -k 